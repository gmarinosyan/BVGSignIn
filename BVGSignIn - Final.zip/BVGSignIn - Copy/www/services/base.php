<?php
session_start(); 
$dbhost = "localhost"; // this will ususally be 'localhost', but can sometimes differ
$dbname = "bvgsignin"; // the name of the database that you are going to use for this project
$dbuser = "admin"; // the username that you created, or were given, to access your database
$dbpass = "bvgsignin"; // the password that you created, or were given, to access your database

?>