<?php
session_start(); 
$dbhost = "localhost"; // this will ususally be 'localhost', but can sometimes differ
$dbname = "bvgsignin"; // the name of the database that you are going to use for this project
$dbuser = "admin"; // the username that you created, or were given, to access your database
$dbpass = "bvgsignin"; // the password that you created, or were given, to access your database
header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1.
header('Pragma: no-cache'); // HTTP 1.0.
header('Expires: 0'); // Proxies.
//@mysql_connect($dbhost, $dbuser, $dbpass) or die("MySQL Error: " . mysql_error());
//mysql_select_db($dbname) or die("MySQL Error: " . mysql_error());
?>